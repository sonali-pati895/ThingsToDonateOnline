import React, { Component } from 'react';


 class DonatedProduct extends React.Component {
  static displayName = DonatedProduct.name;

  constructor (props) {
    super(props);
    this.state = {
      
product: [
  {
     pid: "",
      pname: "",
      did: [  ],
     
      
      image:"" ,
      quantity:0,
      pstatus: ""
  }],



    loading: true };
   

 


  }
  componentDidMount=()=>{
    const url="http://localhost:8080/products";

    fetch(url)
    .then(response => response.json())
    .then(data => {
      this.setState({ product : data, loading: false });
      this.setState({ did: data, loading: false });
      
    });
  }
   
  

    
    render=()=>
    {
    return (
              


<table className='table table-border' >
         <thead className="thead-dark" classname="app flex-row align-items-center">  
         <tr>  
                        <th >Product ID</th>  
                        <th scope="col">product Name</th>  
                        <th scope="col">Donor information</th>
                        <th scope="col">Image </th>  
                        <th scope="col">quantity</th>
                        <th scope="col">product status</th>  
                        
                        
                       
                          
                    </tr>  
                </thead>  
                <tbody>  
                    {
                    this.state.product.map((item,i)=>  
                        
                  
                    <tr key={item.pid}>  
                        <td>{item.pid}</td>
                        <td>{item.pname}</td> 

                        <td>{Object.values(item).map((sub)=>{
                       return<table><tr key={sub.did}>
                          
                           <td>{sub.fname}</td>
                     
                           <td>{sub.lname}</td>
                        
                           <td>{sub.address}</td>
                           <td>{sub.contactno}</td>


                         
                         <td>{Object.values(sub).map((subject)=>{
                         return<table><tr key={subject.uno}>

                        
                        
                         </tr></table>}
                         )}
                      
                         
                         </td>

                      
                      


                        </tr>
                        </table>
                        }
                           )}
                     </td>

                       

                        
                       

                        <td>{item.image}</td>  
                        <td>{item.quantity}</td>
                        <td>{item.pstatus}</td>  
                            
                          
                           
                        </tr>  
                     
                        
                       
                  


                    )
                    
                    
                    
                    } 
                </tbody>  


                <td> <li className="list-group-item"><a className="btn btn-outline-success" href="#">Contact With Respective Donor</a></li></td>
      </table>
    );
  }

  /*render () {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : FetchData.renderreceiver_reqTable(this.state.receiver_req);

    return (
      <div>
         
        {contents}
      </div>
    );
  }*/
}
export default  DonatedProduct;