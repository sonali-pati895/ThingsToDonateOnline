import React, { Component } from 'react';


 class SocialWork extends React.Component {
  static displayName = SocialWork.name;

  constructor (props) {
    super(props);
    this.state = {
      
socialwork: [
  {  wid:"",
     rid: [],
      donateditem: "",
      rcipient: "",
     
      
      location:"" ,
      datetime:0,
      description: ""
  }],



    loading: true };
   

 


  }
  componentDidMount=()=>{
    const url="http://localhost:8080/allwork";

    fetch(url)
    .then(response => response.json())
    .then(data => {
      this.setState({ socialwork : data, loading: false });
      this.setState({ rid: data, loading: false });
      
    });
  }
   
  

    
    render=()=>
    {
    return (
              


<table className='table table-border'>
         <thead className="thead-dark">  
         <tr>  
                        <th scope="col">Social Work ID</th>  
                        <th scope="col">Receiver Information</th>  
                        <th scope="col"><th>Donated Items</th></th>

                        <th scope="col">Recipient </th>  
                        <th scope="col">Location</th>
                        <th scope="col">Date </th>  
                        <th scope="col">Description</th> 
                          
                    </tr>  
                </thead>  
                <tbody>  
                    {
                    this.state.socialwork.map((item,i)=>  
                        
                  
                    <tr key={item.wid}>  
                        <td>{item.wid}</td>
                        

                        <td>{Object.values(item).map((sub)=>{
                       return<table><tr key={sub.rid}>
                        

                         
                         <td>{Object.values(sub).map((subject)=>{
                         return<table><tr key={subject.reqid}>

                        
                        <td>{subject.rname}</td>
                        
                         </tr></table>}
                         )}
                      
                         
                         </td>


                        </tr>
                        </table>
                        }
                           )}
                     </td>


                        <td>{item.donateditem}</td>  
                        <td>{item.recipient}</td>
                        <td>{item.location}</td>  
                        <td>{item.datetime}</td>  
                        <td>{item.description}</td>  
                           
                        </tr>  
                     
                        
                       
                  


                    )
                    
                    
                    
                    } 
                </tbody>  
      </table>
    );
  }

  /*render () {
    let contents = this.state.loading
      ? <p><em>Loading...</em></p>
      : FetchData.renderreceiver_reqTable(this.state.receiver_req);

    return (
      <div>
         
        {contents}
      </div>
    );
  }*/
}
export default  SocialWork;