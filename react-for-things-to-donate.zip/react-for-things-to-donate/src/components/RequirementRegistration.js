import React from 'react';
import { Button, Card, CardFooter, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


class RequirementRegistration extends React.Component{
  constructor(props) {
    super(props);
    this.state = {

                    categories: [],
                    subcategories: [],
                    cid: 0,
                  productrequirement: [{
                   pname:'',
                   sid:[],
                   rid:[],
                  description: '',
                  register:''        
                }]
              }
              this.cid=this.cid.bind(this)
              this.pname = this.pname.bind(this);
              this.sid = this.sid.bind(this);
                this.rid = this.rid.bind(this);
                 this.description = this.description.bind(this);
                 this.register=this.register.bind(this);
              
              }
              componentDidMount=()=>{
                fetch("http://localhost:8080/allcat")
                .then(resp => resp.json())
                .then(data => this.setState({categories: data}))
            }
       
            cid=(event)=>{
                this.setState({cid: event.target.value})
                alert(event.target.value)
                 fetch("http://localhost:8080/getByid?cid="+event.target.value)
               .then(resp => resp.json())
                .then(data => this.setState({subcategories: data}))
                //this.getSubCat();
            }
       
            getSubCat=()=>{
                alert(this.state.cid)
                 fetch("http://localhost:8080/getByid?cid="+this.state.cid)
               .then(resp => resp.json())
                .then(data => this.setState({subcategories: data}))
            }
              
              pname(event) {
         
                this.setState({ pname: event.target.value })
          
              }
              sid(event) {
         
                this.setState({ sid: event.target.value })
          
              }
              rid(event) {
         
                this.setState({ rid: event.target.value })
          
              }
            
              description(event) {
         
                this.setState({ description: event.target.value })
          
              }
      
         
          
            register(event) {

      
                fetch('http://localhost:8080/saveproductreq', {
               
                  method: 'post',
         
                  headers: {
           
                    'Accept': 'application/json',
         
                    'Content-Type': 'application/json'
      
                  },
                 
                  
                "body": JSON.stringify({
        
                     pname:this.state.pname,
                     sid:this.state.sid,
                    rid:this.state.rid,
                   description: this.state.description,
                  
                 })
        
                })
               
                .then((Response) => Response.json())
                      //.then(response => { console.log(response)
                     // })
                     // .catch(err => {
                       // console.log(err);
                     // });
                     .then(data =>{
                      
                          this.setState({rid: data})

                           alert("You Are Sucessfully Added Requirement");
                            this.props.history.push("/receiverhome");
                  
                  })
                
          
                }
        render(){
            return(
                <div className="app flex-row align-items-center">
                  
                              <Container>
                      
                                <Row className="justify-content-center">
                      
                                  <Col md="9" lg="7" xl="6">
                      
                                    <Card className="mx-4">
                  
                                      <CardBody className="p-4">
                    
                                        <Form>
                      
                                          <div class="row" className="mb-2 pageheading">
                  
                                            <div class="col-sm-12 btn btn-outline-info">
                    
                                              <h2>Product Requirement</h2>
                    
                                              </div>
              
                                          </div>
                                          <lable>Product Name</lable><br></br>
                                          
                                          <InputGroup className="mb-3">
                
                                            
                                            <Input type="text"  onChange={(event) =>this.pname(event)} placeholder="Enter Product Name" />
                  
                                          </InputGroup>
                                          <label>Select Category</label>
                                          <InputGroup className="mb-3">
                                            <select onChange={this.cid}>
                                              {
                                                  this.state.categories.map(cat => {
                                                      return(<option value={cat.cid}>{cat.cname}</option>)
                                                  })
                                              }
                                            
                                          </select>
                                          </InputGroup>
                                          {/*<p>{this.state.cid}</p>*/}
                                        <br/>
                                        <label>Select subcategory</label>
                                        <InputGroup className="mb-3"> 
                                        <select onChange={this.sid} >
                                        {
                                              this.state.subcategories.map(subcat => {
                                                  return(<option value={subcat.sid}>{subcat.sname}</option>)
                                              })
                                          }
                                        </select><br></br>
                                        </InputGroup><br></br>
                                        <label>Select rid</label>                                        
                                        <InputGroup className="mb-3">
                                        <Input type="text" className="form-control" onChange={(event) =>this.rid(event)} placeholder="Description" />
                  
                                            </InputGroup><br></br> 
                                          <lable>Description</lable><br></br>
                                          <InputGroup className="mb-3">
                
                                            <Input type="text" className="form-control" onChange={(event) =>this.description(event)} placeholder="Description" />
                  
                                          </InputGroup>      
                                          <Button  className="btn btn-block" onClick={(event) => this.register(event)}  color="success" >Submit</Button>

                                          
                               
                                        </Form>
                  
                                      </CardBody>
                  
                                    </Card>
                  
                                  </Col>
              
                                </Row>
              
                              </Container>
                  
                            </div>
            );
    }
}

export default RequirementRegistration;