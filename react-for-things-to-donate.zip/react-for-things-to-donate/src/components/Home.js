import { logDOM } from "@testing-library/dom";
import React from "react";
import Background from "./Background";


class Home extends React.Component{
    render()
    {
        return(
            <div id="banner">
            <div class="navbar">
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="/login">Login</a></li>
                <li><a href="/register">Register</a></li>
                <li><a href="/">About Us</a></li>
            </ul>
            </div>
            <div class="content">
            <h1>Donate Things</h1>
            <p>It does not matter how much we donate,it matters whether the donation is meaningful.<br></br> How to define meaningful? Let society and history judge.</p>
            <div>
                <button class="hbtn" type="button"><span class="span"></span><a class="ahome" href="/donorregister">DONATE</a></button>
                <button class="hbtn" type="button"><span class="span"></span><a class="ahome" href="/receiverregister">RECEIVE</a></button>
            </div>
            </div>
            </div>
        );
    }
}
export default Home;