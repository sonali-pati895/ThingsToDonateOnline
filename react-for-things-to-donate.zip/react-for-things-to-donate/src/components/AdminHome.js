import React from 'react';
class AdminHome extends React.Component{
    constructor(props){
        super(props);

    }
    render(){
        return(
            <div className="jumbotron">
                <h1>Hello Admin</h1><br/>
                <form className="col-sm-5">
                <ul className="list-group">
                <li className="list-group-item"><a className="stretched-link" href="/reqmgmt"> View Request Of Registration</a></li>
                <li className="list-group-item"><a className="stretched-link" href="/donatedproduct"> View Donated Itemslist</a></li>
                <li className="list-group-item"><a className="stretched-link" href="/socialwork"> View Social Deeds</a></li>
                <li className="list-group-item"><a href="/login" className="btn btn-outline-primary">Logout</a></li>
                </ul>
                </form>
            </div>
        )
    }
}
export default AdminHome;