import React from "react";
import { Button, Card, CardFooter, CardBody, CardGroup, Col, Container, Form, Input, InputGroup, InputGroupAddon, InputGroupText, Row } from 'reactstrap';


 class ReceiverRegister extends React.Component{
     constructor(props) {
        super(props);
        this.state = {
          receiver: {
            
         
                      
                      
                        uid:'',
                      rname: '',
                      pwd:'',
                
                                      
                      uniqueid: '',
                      email:'',
                      
                      address:'',

                      requeststatus:'',
                      
                      contactno: ''
            
                    }
                  }
                    this.uid= this.uid.bind(this);
                    this.rname = this.rname.bind(this);
                    this.uniqueid = this.uniqueid.bind(this); 
                    this.email = this.email.bind(this);
                    this.pwd = this.pwd.bind(this);
                    this.address = this.address.bind(this);
                    this.contactno = this.contactno.bind(this);
                    this.register = this.register.bind(this);
            
                  }
                  uid(event) {
             
                    this.setState({ uid: event.target.value })
              
                  }
                  rname(event) {
             
                    this.setState({ rname: event.target.value })
              
                  }
                  uniqueid(event) {
           
                    this.setState({uniqueid: event.target.value })
              
                  }
                  email(event) {
             
                    this.setState({ email: event.target.value })
            
                  }
                
                  pwd(event) {
             
                    this.setState({ pwd: event.target.value })
              
                  }
                  address(event) {
               
                    this.setState({ address: event.target.value })
            
                  }
                  contactno(event) {
           
                    this.setState({ contactno: event.target.value })
             
                  }
                register(event) {
                     alert("Hello");
          
                    fetch('http://localhost:8080/saver', {
                   
                      method: 'post',
             
                      headers: {
               
                        'Accept': 'application/json',
             
                        'Content-Type': 'application/json'
          
                      },
                     
                      
                    "body": JSON.stringify({
                        
                       uid:this.state.uid,  
                       rname: this.state.rname,
                       uniqueid: this.state.uniqueid,
                       email: this.state.email,
                       pwd:this.state.pwd,  
                        address: this.state.address,
                        contactno: this.state.contactno
                     })
            
                    })
                   
                    .then((response) => {
                           if (response.status == 200)
                           {
                            alert("Wait Till Request Permitted !!");
                            this.props.history.push("/login");                 
                          

                           }
                           else
                           alert("Registration failed");

                          })
                         
                              
                                            
                    
              
                    }
             
               
             
               
                  render() {
              
               
                    return (
             
                        <div className="app flex-row align-items-center">
               
                          <Container>
                  
                            <Row className="justify-content-center">
                  
                              <Col md="9" lg="7" xl="6">
                  
                                <Card className="mx-4">
               
                                  <CardBody className="p-4">
                
                                    <Form>
                  
                                      <div class="row" className="mb-2 pageheading">
               
                                        <div class="col-sm-12 btn btn-primary">
                 
                                          <h2>Sign Up</h2>
                
                                          </div>
           
                                      </div>
                                      
                                      
                                      
                                      <lable>User ID</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="uid"  onChange={(event) =>this.uid(event)} placeholder="Enter Username" />
               
                                      </InputGroup>
                                      <lable>Receiver Name</lable><br></br>
                                      <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.rname(event)} placeholder="Enter NGO/COMPANY/ORGANIZATION Name" />
               
                                      </InputGroup>
                                      
                                      <lable>UniqueId</lable><br></br>
                                        <InputGroup className="mb-3">
             
                                        <Input type="text"  onChange={(event) =>this.uniqueid(event)} placeholder="Enter Unique Id" />
               
                                      </InputGroup>
                                      <lable>Email</lable><br></br>
                                      <InputGroup className="mb-3">
                                     <Input type="email"  onChange={(event) =>this.email(event)} placeholder="Enter email" />
                  
                                      </InputGroup>
                                      <label>Password</label>
                                      <InputGroup className="mb-3">
             
                                        <Input type="password"  onChange={(event) =>this.pwd(event)} placeholder="Enter password" />
               
                                      </InputGroup>
                                     
                                      <lable>Address</lable><br></br>
                                      <InputGroup className="mb-4">
              
                                        <Input type="text"  onChange={(event) =>this.address(event)} placeholder="Enter address" />
           
                                      </InputGroup>
                                      
                                      <InputGroup className="mb-4">
                                        <select className="btn btn-success dropdown-toggle " name="requeststatus" id="requeststatus" >
                                          <option value="0">0</option>
                                          <option value="1" disabled>1</option>
                                        </select>
                                      
                                     </InputGroup>
                                     <lable>Contact Number</lable><br></br>
                                     <InputGroup className="mb-4">
             
                                        <Input type="number"  onChange={(event) =>this.contactno(event)} placeholder="Enter contactno" />
                                     </InputGroup>
              
                                      <Button  onClick={(event) => this.register(event)}  color="success" >Create Account</Button>
              
                                    </Form>
               
                                  </CardBody>
               
                                </Card>
               
                              </Col>
           
                            </Row>
          
                          </Container>
               
                        </div>
               
                      );
              
                    }
               
                  }
                  export default ReceiverRegister;