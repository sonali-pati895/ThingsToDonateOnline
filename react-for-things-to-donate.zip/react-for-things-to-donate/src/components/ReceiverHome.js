import React from 'react';
class ReceiverHome extends React.Component{
    constructor(props){
        super(props);

    }
    render(){
        return(
            
            <div >
                <h1> Welcome Receiver </h1><br/>
                <div className="jumbotron">
                <form className="col-sm-5">
                <ul className="list-group-flush">
                <li className="list-group-item"><a href="/donatedproduct"> View Donated Product List</a></li>
                <li className="list-group-item"><a href="/requirementregistration"> Add your Product Requirement</a></li>
                <li  className="list-group-item"><a href="/socialworkform"> About your social deeds</a></li>
                <li className="list-group-item"><a className="btn btn-outline-primary btn-block" href="/login">Logout</a></li>
                </ul>
                </form>
                </div>
            </div>
        )
    }
}
export default ReceiverHome;